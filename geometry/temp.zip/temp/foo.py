def div3(a):
    return a / 3.