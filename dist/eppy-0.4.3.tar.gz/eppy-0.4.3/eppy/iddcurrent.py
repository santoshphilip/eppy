import iddv800 as iddcurrent
# import iddv7 as iddcurrent